﻿using EventEase1.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

public class BookingsController : Controller
{
    private readonly ApplicationDbContext _context;

    public BookingsController(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index()
    {
        var bookings = _context.Bookings
            .Include(b => b.Event)
            .Include(b => b.Venue);
        return View(await bookings.ToListAsync());
    }

    public IActionResult Create()
    {
        ViewData["EventId"] = new SelectList(_context.Events, "EventId", "EventName");
        ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName");
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("BookingId,EventId,VenueId,BookingDate")] Booking booking)
    {
        // Check for double booking
        var conflict = await _context.Bookings.AnyAsync(b =>
            b.VenueId == booking.VenueId && b.BookingDate.Date == booking.BookingDate.Date);

        if (conflict)
        {
            ModelState.AddModelError("", "This venue is already booked on the selected date.");
        }

        if (ModelState.IsValid)
        {
            _context.Add(booking);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        ViewData["EventId"] = new SelectList(_context.Events, "EventId", "EventName", booking.EventId);
        ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName", booking.VenueId);
        return View(booking);
    }
}
