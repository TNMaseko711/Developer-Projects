﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EventEase1.Models; // Ensure this is the correct namespace

public class EventsController : Controller
{
    private readonly ApplicationDbContext _context;

    public EventsController(ApplicationDbContext context)
    {
        _context = context;
    }

    // GET: Events
    public async Task<IActionResult> Index()
    {
        var events = _context.Events.Include(e => e.Venue);
        return View(await events.ToListAsync());
    }

    // GET: Events/Details/5
    public async Task<IActionResult> Details(int? id)
    {
        if (id == null) return NotFound();

        var evt = await _context.Events
            .Include(e => e.Venue)
            .FirstOrDefaultAsync(m => m.EventId == id);

        if (evt == null) return NotFound();

        return View(evt);
    }

    // GET: Events/Create
    public IActionResult Create()
    {
        // Populate the drop-down list with venues
        ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName");
        return View();
    }

    // POST: Events/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("EventId,EventName,EventDate,Description,VenueId")] Event evt)
    {
        if (ModelState.IsValid)
        {
            _context.Add(evt);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // If the model state is invalid, return to the view with the VenueId drop-down list populated
        ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName", evt.VenueId);
        return View(evt);
    }

    // GET: Events/Edit/5
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null) return NotFound();

        var evt = await _context.Events.FindAsync(id);
        if (evt == null) return NotFound();

        ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName", evt.VenueId);
        return View(evt);
    }

    // POST: Events/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [Bind("EventId,EventName,EventDate,Description,VenueId")] Event evt)
    {
        if (id != evt.EventId) return NotFound();

        if (ModelState.IsValid)
        {
            try
            {
                _context.Update(evt);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Events.Any(e => e.EventId == id))
                    return NotFound();
                else
                    throw;
            }
            return RedirectToAction(nameof(Index));
        }

        ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName", evt.VenueId);
        return View(evt);
    }

    // GET: Events/Delete/5
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null) return NotFound();

        var evt = await _context.Events
            .Include(e => e.Venue)
            .FirstOrDefaultAsync(m => m.EventId == id);

        if (evt == null) return NotFound();

        return View(evt);
    }

    // POST: Events/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var evt = await _context.Events
            .Include(e => e.Bookings)
            .FirstOrDefaultAsync(e => e.EventId == id);

        // Only delete if there are no bookings associated with the event
        if (evt != null && !evt.Bookings.Any())
        {
            _context.Events.Remove(evt);
            await _context.SaveChangesAsync();
        }

        return RedirectToAction(nameof(Index));
    }
}
