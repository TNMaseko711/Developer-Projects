# PulseVote Backend (Starter)

This is a minimal Express backend scaffold for PulseVote.

## Scripts
- `npm run dev` — start with nodemon
- `npm start` — start with node

## Endpoints
- `GET /` — health message
- `GET /test` — JSON test

## Quickstart
1. Copy `.env.example` to `.env` and adjust.
2. Install deps: `npm install`
3. Run: `npm run dev`
4. Visit http://localhost:5000/ and http://localhost:5000/test

## SSL
- Place generated `key.pem` and `cert.pem` in `ssl/`.
- Later we will switch the server to HTTPS for local testing.
