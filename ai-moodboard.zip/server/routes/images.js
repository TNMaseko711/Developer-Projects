const express = require('express')
const router = express.Router()
const axios = require('axios')

// Simple proxy to Unsplash search
router.get('/', async (req, res) => {
  const q = req.query.q || 'mood'
  try {
    const accessKey = process.env.UNSPLASH_ACCESS_KEY
    if (!accessKey) return res.status(400).json({ error: 'UNSPLASH_ACCESS_KEY not configured' })
    const r = await axios.get(`https://api.unsplash.com/search/photos`, {
      params: { query: q, per_page: 12, client_id: accessKey }
    })
    const images = r.data.results.map(i => i.urls.small)
    res.json({ images })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

module.exports = router
