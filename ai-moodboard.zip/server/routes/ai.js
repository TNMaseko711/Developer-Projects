const express = require('express')
const router = express.Router()
const axios = require('axios')

/**
 * POST /api/ai/caption
 * body: { theme: string }
 * Returns a simple AI-generated caption and an array of image URLs (from Unsplash proxy).
 *
 * NOTE: This is a placeholder implementation. To enable real AI:
 * - Install and configure OpenAI SDK and use OPENAI_API_KEY from env.
 * - For images, use Unsplash API with UNSPLASH_ACCESS_KEY.
 */

router.post('/caption', async (req, res) => {
  const theme = req.body.theme || 'mood'
  // Placeholder caption generation
  const caption = `A ${theme} mood — curated with AI.`

  // Attempt to fetch images from Unsplash (if API key provided)
  let images = []
  try {
    const accessKey = process.env.UNSPLASH_ACCESS_KEY
    if (accessKey) {
      const q = encodeURIComponent(theme)
      const r = await axios.get(`https://api.unsplash.com/search/photos?query=${q}&per_page=6&client_id=${accessKey}`)
      images = r.data.results.map(i => i.urls.small)
    }
  } catch (err) {
    console.warn('Unsplash fetch failed:', err.message)
  }

  res.json({ caption, images })
})

module.exports = router
