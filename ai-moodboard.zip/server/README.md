Server (Express + Socket.IO)

Run:
```
cd server
npm install
npm run dev
```

Endpoints:
- POST /api/ai/caption  -> { theme: string }  (returns AI caption + suggested images)
- GET  /api/images?q=... -> proxy to Unsplash

Socket.IO events:
- join (room)          -> socket joins room
- add_tile (room,tile) -> server broadcasts tile to room
