require('dotenv').config()
const express = require('express')
const http = require('http')
const cors = require('cors')
const { Server } = require('socket.io')
const aiRoutes = require('./routes/ai')
const imagesRoutes = require('./routes/images')

const app = express()
app.use(cors())
app.use(express.json())

app.use('/api/ai', aiRoutes)
app.use('/api/images', imagesRoutes)

const server = http.createServer(app)
const io = new Server(server, { cors: { origin: '*' } })

// Simple in-memory state per room (demo purposes only)
const rooms = {}

io.on('connection', (socket) => {
  console.log('socket connected', socket.id)

  socket.on('join', ({ room }) => {
    socket.join(room)
    if (!rooms[room]) rooms[room] = { tiles: [] }
    // send current state
    socket.emit('state', rooms[room])
  })

  socket.on('add_tile', ({ room, tile }) => {
    if (!rooms[room]) rooms[room] = { tiles: [] }
    rooms[room].tiles.push(tile)
    io.to(room).emit('tile_added', tile)
  })

  socket.on('disconnect', () => {
    console.log('socket disconnected', socket.id)
  })
})

const PORT = process.env.PORT || 4000
server.listen(PORT, () => console.log('Server running on', PORT))
