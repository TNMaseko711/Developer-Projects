# AI Moodboard Generator 🎨

Starter repo for the AI Moodboard Generator — a collaborative moodboard builder with AI captions and image search.

This is a skeleton project intended to get you up and running quickly:
- `client/` — Next.js frontend (minimal scaffold)
- `server/` — Express backend with Socket.IO and placeholder endpoints

See `.env.example` files for required environment variables.

## Quick start (local)
1. Install dependencies for client and server.
2. Run the backend and frontend concurrently (or in separate terminals).
3. Connect to `http://localhost:3000` for the frontend.

## File structure
```
ai-moodboard/
├── client/
├── server/
├── README.md
└── .gitignore
```

## Environment variables
Copy `.env.example` into `.env` files in `client` and `server` folders and populate keys:
```
OPENAI_API_KEY=your_openai_key
UNSPLASH_ACCESS_KEY=your_unsplash_key
```

## License
MIT © 2025
