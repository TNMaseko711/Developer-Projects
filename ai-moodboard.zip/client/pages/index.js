import { useState } from 'react'
import axios from 'axios'
import { useRouter } from 'next/router'

export default function Home() {
  const [theme, setTheme] = useState('')
  const router = useRouter()

  const handleCreate = async () => {
    // In a full app you'd create room on server. Here we generate a pseudo id.
    const id = Math.random().toString(36).slice(2, 9)
    router.push(`/board/${id}?theme=${encodeURIComponent(theme)}`)
  }

  return (
    <main style={{display: 'flex', gap: 24, flexDirection: 'column', padding: 24}}>
      <h1>AI Moodboard Generator</h1>
      <p>Type a mood or theme and create a collaborative board.</p>
      <input
        placeholder="e.g. cozy cyberpunk cafe"
        value={theme}
        onChange={(e) => setTheme(e.target.value)}
        style={{padding: '8px 12px', width: 360}}
      />
      <div>
        <button onClick={handleCreate} style={{padding: '8px 12px'}}>Create moodboard</button>
      </div>
      <small>Note: this is a starter scaffold. Connect to the server for AI and images.</small>
    </main>
  )
}
