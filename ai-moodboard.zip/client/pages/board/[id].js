import { useEffect, useState, useRef } from 'react'
import { io } from 'socket.io-client'
import axios from 'axios'
import { useRouter } from 'next/router'

let socket

export default function Board() {
  const router = useRouter()
  const { id } = router.query
  const [tiles, setTiles] = useState([])
  const [caption, setCaption] = useState('')
  const [theme, setTheme] = useState('')
  const mounted = useRef(false)

  useEffect(() => {
    if (!id) return
    const base = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:4000'
    socket = io(base)
    socket.emit('join', { room: id })

    socket.on('state', (s) => setTiles(s.tiles || []))
    socket.on('tile_added', (tile) => setTiles(t => [...t, tile]))

    return () => {
      socket.disconnect()
    }
  }, [id])

  useEffect(() => {
    if (!router.isReady) return
    const q = router.query.theme || ''
    setTheme(q)
  }, [router.isReady])

  const addAIContent = async () => {
    const base = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:4000'
    try {
      const res = await axios.post(`${base}/api/ai/caption`, { theme })
      const { caption: aiCaption, images } = res.data
      setCaption(aiCaption)
      // Add the first image as a tile via socket
      const tile = { id: Math.random().toString(36).slice(2,9), img: images?.[0] || '', caption: aiCaption }
      socket.emit('add_tile', { room: id, tile })
    } catch (err) {
      console.error(err)
      alert('AI endpoint not available. See server README.')
    }
  }

  return (
    <main style={{padding: 24}}>
      <h2>Board: {id}</h2>
      <p>Theme: {theme}</p>
      <div style={{display: 'flex', gap: 12, marginTop: 12}}>
        <button onClick={addAIContent} style={{padding: '8px 12px'}}>Generate AI caption + image</button>
      </div>

      <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 12, marginTop: 24}}>
        {tiles.map(t => (
          <div key={t.id} style={{border: '1px solid #ddd', padding: 8, borderRadius: 6}}>
            {t.img ? <img src={t.img} alt="" style={{width: '100%', height: 120, objectFit: 'cover'}} /> : <div style={{height:120, background:'#f3f3f3'}}/>}
            <div style={{marginTop:8}}>{t.caption}</div>
          </div>
        ))}
      </div>
    </main>
  )
}
