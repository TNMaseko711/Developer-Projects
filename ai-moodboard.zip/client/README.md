Client (Next.js)
Run:
```
cd client
npm install
npm run dev
```
