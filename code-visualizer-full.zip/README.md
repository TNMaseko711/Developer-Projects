# Zero to Hero Code Visualizer 📊

Starter repo for the Code Visualizer — upload Python or JavaScript files and visualize function dependencies and complexity.

This scaffold includes:
- `server/` — FastAPI backend with a Python analyzer (AST-based).
- `client/` — React frontend with D3.js visualization.

Run backend:
```
cd server
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Run frontend:
```
cd client
npm install
npm start
```
