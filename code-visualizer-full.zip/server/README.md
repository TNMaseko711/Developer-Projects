Server (FastAPI)

This server exposes a simple endpoint to analyze Python files.

Install:
pip install -r requirements.txt

Run:
uvicorn main:app --reload --port 8000

Endpoints:
POST /analyze/python  (multipart/form-data file upload)
GET  /health
