"""Basic Python analyzer using ast.

Outputs:
{
  "functions": {
     "<func_name>": {
        "lineno": int,
        "end_lineno": int,
        "calls": ["other_func", ...],
        "complexity": int,
        "vars": ["x","y",...]
     },
     ...
  },
  "calls": [ ["caller","callee"], ... ]
}

This is a starter implementation. It is intentionally small and readable so you can extend it.
"""
import ast
from collections import defaultdict

def _get_name(node):
    # Try to infer a name for call targets
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return None

class FunctionVisitor(ast.NodeVisitor):
    def __init__(self):
        self.functions = {}
        self.current = None

    def visit_FunctionDef(self, node):
        fname = node.name
        info = {
            "lineno": node.lineno,
            "end_lineno": getattr(node, "end_lineno", None),
            "calls": set(),
            "vars": set(),
            "complexity": 1  # base complexity
        }
        self.functions[fname] = info
        prev = self.current
        self.current = fname
        # visit body for calls/vars/complexity
        self.generic_visit(node)
        self.current = prev

    def visit_Call(self, node):
        if self.current is None:
            return
        name = _get_name(node.func)
        if name:
            self.functions[self.current]["calls"].add(name)
        self.generic_visit(node)

    def visit_Name(self, node):
        if self.current is None:
            return
        if isinstance(node.ctx, ast.Store) or isinstance(node.ctx, ast.Load):
            self.functions[self.current]["vars"].add(node.id)

    # Increase complexity for branching constructs
    def visit_If(self, node):
        if self.current:
            self.functions[self.current]["complexity"] += 1
        self.generic_visit(node)

    def visit_For(self, node):
        if self.current:
            self.functions[self.current]["complexity"] += 1
        self.generic_visit(node)

    def visit_While(self, node):
        if self.current:
            self.functions[self.current]["complexity"] += 1
        self.generic_visit(node)

    def visit_Try(self, node):
        if self.current:
            self.functions[self.current]["complexity"] += 1
        self.generic_visit(node)

def analyze_python_source(source):
    tree = ast.parse(source)
    visitor = FunctionVisitor()
    visitor.visit(tree)

    # postprocess: convert sets to lists
    functions = {}
    calls = []
    for fname, info in visitor.functions.items():
        calls_list = list(info["calls"])
        vars_list = list(info["vars"])
        functions[fname] = {
            "lineno": info["lineno"],
            "end_lineno": info["end_lineno"],
            "calls": calls_list,
            "vars": vars_list,
            "complexity": info["complexity"]
        }
        for callee in calls_list:
            calls.append([fname, callee])

    return {"functions": functions, "calls": calls}
