import json
import subprocess
from pathlib import Path

def analyze_js(file_path):
    try:
        # This assumes Node.js + esprima is installed
        script = f"""
        const fs = require('fs');
        const esprima = require('esprima');
        const content = fs.readFileSync('{file_path}', 'utf8');
        const ast = esprima.parseScript(content, { tolerant: true });
        const functions = [];
        const calls = [];
        
        function traverse(node, parentFunc) {
            if (!node) return;
            if (node.type === 'FunctionDeclaration' && node.id) {
                functions.push(node.id.name);
                parentFunc = node.id.name;
            }
            if (node.type === 'CallExpression' && node.callee && node.callee.name) {
                calls.push({ from: parentFunc || 'global', to: node.callee.name });
            }
            for (let key in node) {
                if (node[key] && typeof node[key] === 'object') {
                    traverse(node[key], parentFunc);
                }
            }
        }
        
        traverse(ast, null);
        console.log(JSON.stringify({ functions, calls }));
        """
        temp_js = Path(file_path).parent / 'temp_parse.js'
        temp_js.write_text(script)
        output = subprocess.check_output(['node', str(temp_js)], text=True)
        temp_js.unlink()
        return json.loads(output)
    except Exception as e:
        return { "error": str(e) }
