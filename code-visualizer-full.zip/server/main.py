from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from analyzers.python_analyzer import analyze_python
from analyzers.js_analyzer import analyze_js_source
import json

app = FastAPI(title="Code Visualizer API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/analyze/python")
async def analyze_python(file: UploadFile = File(...)):
    if not file.filename.endswith(".py"):
        raise HTTPException(status_code=400, detail="Only .py files are accepted for this endpoint.")
    source = (await file.read()).decode("utf-8")
    result = analyze_python_source(source)
    return result

@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/analyze/js")
async def analyze_js_code(file: UploadFile = File(...)):
    file_path = f"temp_{file.filename}"
    with open(file_path, "wb") as buffer:
        buffer.write(await file.read())
    result = analyze_js(file_path)
    os.remove(file_path)
    return result
