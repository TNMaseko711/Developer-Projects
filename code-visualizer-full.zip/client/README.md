Client (React + D3)

Run:
cd client
npm install
npm start

Then open http://localhost:3000
