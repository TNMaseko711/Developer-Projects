import React, { useState } from 'react'
import axios from 'axios'
import Graph from './components/Graph'

export default function App(){
  const [file, setFile] = useState(null)
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const handleFile = (e) => setFile(e.target.files[0])

  const upload = async () => {
    if (!file) return alert('Select a .py file')
    const form = new FormData()
    form.append('file', file)
    setLoading(true)
    try {
      const res = await axios.post('http://localhost:8000/analyze/python', form, {
        headers: {'Content-Type': 'multipart/form-data'}
      })
      setData(res.data)
    } catch (err) {
      console.error(err)
      alert('Server error. Make sure the backend is running on http://localhost:8000')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{padding:24, fontFamily: 'Inter, system-ui, sans-serif'}}>
      <h1>Zero to Hero — Code Visualizer</h1>
      <p>Upload a Python file (.py) and get a function dependency graph and complexity heatmap.</p>
      <input type="file" accept=".py" onChange={handleFile} />
      <button onClick={upload} style={{marginLeft:12}}>Analyze</button>
      {loading && <div>Analyzing...</div>}
      {data && (
        <>
          <h3>Results</h3>
          <Graph data={data} />
          <pre style={{marginTop:12, maxHeight:200, overflow:'auto', background:'#f7f7f7', padding:12}}>
            {JSON.stringify(data, null, 2)}
          </pre>
        </>
      )}
    </div>
  )
}
