import React, { useEffect, useRef } from 'react'
import * as d3 from 'd3'

export default function Graph({ data }){
  const ref = useRef()

  useEffect(() => {
    if (!data) return
    const width = 800, height = 500
    const svg = d3.select(ref.current)
      .attr('viewBox', [0,0,width,height])
      .style('border','1px solid #eee')

    svg.selectAll('*').remove()

    // build nodes from functions
    const funcs = data.functions || {}
    const nodes = Object.keys(funcs).map(name => ({
      id: name,
      complexity: funcs[name].complexity || 1
    }))

    // include callee nodes that may not be defined (external)
    data.calls.forEach(([caller, callee]) => {
      if (!nodes.find(n => n.id === callee)) {
        nodes.push({ id: callee, complexity: 1 })
      }
    })

    const links = data.calls.map(([caller, callee]) => ({ source: caller, target: callee }))

    const color = (c) => {
      // map complexity to color (green -> red)
      const v = Math.min(10, c) / 10
      const r = Math.round(255 * v)
      const g = Math.round(200 * (1 - v))
      return `rgb(${r},${g},80)`
    }

    const simulation = d3.forceSimulation(nodes)
      .force('link', d3.forceLink(links).id(d => d.id).distance(120))
      .force('charge', d3.forceManyBody().strength(-300))
      .force('center', d3.forceCenter(width/2, height/2))

    const link = svg.append('g')
      .attr('stroke','#999')
      .selectAll('line')
      .data(links)
      .join('line')
      .attr('stroke-width', 1.5)

    const node = svg.append('g')
      .selectAll('g')
      .data(nodes)
      .join('g')
      .call(drag(simulation))

    node.append('circle')
      .attr('r', d => 8 + (d.complexity || 1) * 2)
      .attr('fill', d => color(d.complexity))

    node.append('text')
      .text(d => d.id)
      .attr('x', 12)
      .attr('y', 4)
      .style('font-size', '12px')

    simulation.on('tick', () => {
      link
        .attr('x1', d => d.source.x)
        .attr('y1', d => d.source.y)
        .attr('x2', d => d.target.x)
        .attr('y2', d => d.target.y)
      node.attr('transform', d => `translate(${d.x},${d.y})`)
    })

    // zoom
    svg.call(d3.zoom().on('zoom', (event) => {
      svg.selectAll('g').attr('transform', event.transform)
    }))

    function drag(sim) {
      function dragstarted(event, d) {
        if (!event.active) sim.alphaTarget(0.3).restart()
        d.fx = d.x; d.fy = d.y
      }
      function dragged(event, d) {
        d.fx = event.x; d.fy = event.y
      }
      function dragended(event, d) {
        if (!event.active) sim.alphaTarget(0)
        d.fx = null; d.fy = null
      }
      return d3.drag()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended)
    }

    return () => simulation.stop()

  }, [data])

  return <svg ref={ref} style={{width:'100%',height:500}} />
}
